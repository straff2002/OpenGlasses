# Fault codes

| Code | Meaning | Manual |
|---|---|---|
| QX1 | Invented fixture fault | install-manual p. 4 |
