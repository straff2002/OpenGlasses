# Fictional site fault codes

FX200: inspect the fictional site fixture.
