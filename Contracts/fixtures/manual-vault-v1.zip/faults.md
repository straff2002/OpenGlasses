# Fictional fault codes

FX100: inspect the fictional fixture.
