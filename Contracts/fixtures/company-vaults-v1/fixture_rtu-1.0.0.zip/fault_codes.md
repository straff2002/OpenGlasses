# Fault codes

| Code | Meaning |
|---|---|
| FX1 | Invented fixture fault |
