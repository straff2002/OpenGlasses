# Safety

Invented fixture: isolate the unit before opening any panel.
