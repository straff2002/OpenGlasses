# Safety

Invented fixture: isolate the QX-100 before opening any panel.
